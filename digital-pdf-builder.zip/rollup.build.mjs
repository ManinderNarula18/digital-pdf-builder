export default {
  input: "main.mjs",
  output: {
    file: "build/bundle.mjs",
    format: "es",
  },
};
