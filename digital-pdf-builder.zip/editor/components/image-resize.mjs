const html = String.raw;
const template = html`
  <input
    type="file"
    ref="fileInput"
    class="fileInput"
    accept="image/png, image/jpeg, image/gif, image/jpg,"
    style="display: none;"
    @change="handleFileChange"
  />
  <button class="btn btn-outline-secondary" @click="choose">Upload</button>
`;

export default {
  template,

  props: {
    mykey: {
      type: String,
      required: true,
    },
  },

  data() {
    return {};
  },
  methods: {
    choose() {
      this.$refs.fileInput.click(); // Use Vue's ref to trigger file input
    },
    handleFileChange(event) {
      const file = event.target.files[0];
      if (!file) return;

      const img = new Image();
      img.onload = () => {
        const base64Image = this.resizeImage(img);
        this.$emit("image", {
          key: this.mykey,
          value: base64Image,
        });
      };
      img.onerror = () => {
        console.error("Failed to load image");
      };
      img.src = URL.createObjectURL(file);
    },
    resizeImage(img) {
      const imgWidth = 1110;
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");

      canvas.width = imgWidth;
      canvas.height = (imgWidth * img.height) / img.width;

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL("image/jpeg");
    },
  },
  mounted() {
    // Any setup needed on mount can be done here
  },
};
