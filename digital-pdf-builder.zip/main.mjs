import Header from "./components/header/template1/header.mjs";

import template1 from "./components/header/template1/header.mjs";
import template2 from "./components/header/template2/header.mjs";

import ftemplate1 from "./components/footer/ftemplate1/template.mjs";
import ftemplate2 from "./components/footer/ftemplate2/template.mjs";

import innertemplate1 from "./components/innerpages/innertemplate1/template.mjs";
import innertemplate2 from "./components/innerpages/innertemplate2/template.mjs";
import innertemplate3 from "./components/innerpages/innertemplate3/template.mjs";
import innertemplate4 from "./components/innerpages/innertemplate4/template.mjs";

import Editor from "./editor/editor.mjs";

// import Modalmenu from '../../modal/modalheadermenu.mjs'; // Import modal module

var all_entires=[];


const { createApp } = Vue;
const App = createApp({
  data() { 

    all_entires=this.loadEntries();

    return {
      editing: true,
      headerlayouts: ["template1"],
      innerlayouts: ["innertemplate1", "innertemplate2", "innertemplate3", "innertemplate4"],
      layouts: ["featured", "post", "news", "newsleft", "features"],
      footerlayouts: ["ftemplate1"],
      entries: this.loadEntries(), // Load from local storage
    };
  },

  methods: {
    defaultVal(key, def) {
      return key === "" ? def : key;
    },
    
    loadEntries() {
       
      const storedEntries = localStorage.getItem("entries");
      return storedEntries ? JSON.parse(storedEntries) : [
        {
          id: "item-1",
          layout: "header",
          title: "Vue Pagebuilder",
          subtitle: "Lorem ipsum dolor site amet.",
          button_text: "Contact Us",
          button_link: "#",
          icon: "fas fa-bolt",
        },
        {
          id: "item-2",
          layout: "post",
          title: "Mauris eleifend ligula",
          body: "Vivamus in nisi commodo, auctor magna vel, viverra turpis.",
        },
      ];
    },

    saveEntries() {
      localStorage.setItem("entries", JSON.stringify(this.entries));
    },

    addEntry(newEntry) {
      this.entries.push(newEntry);
      this.saveEntries();
    },

    // showModal(Item) {
    //   // Create and show the modal with dynamic content passed as arguments
    //   const modal = Modalmenu({
    //     all_entires: Item,  
    //     onClose: () => {
    //       console.log('Modal closed');
    //     }
    //   });
    // },
    
  },

  watch: {
    entries: {
      handler(newEntries) {
        this.saveEntries();
      },
      deep: true, // Watch deeply to catch nested changes
    },
  },

  components: {  
    "wdgt-header": Header,

    "wdgt-template1": template1,
    "wdgt-template2": template2,

    "wdgt-ftemplate1": ftemplate1,
    "wdgt-ftemplate2": ftemplate2,

    "wdgt-innertemplate1": innertemplate1,
    "wdgt-innertemplate2": innertemplate2,
    "wdgt-innertemplate3": innertemplate3,
    "wdgt-innertemplate4": innertemplate4,
    
    "page-editor": Editor,
  },
});

window.addEventListener("load", () => {
  App.mount("main");
  // console.log(App);
});


